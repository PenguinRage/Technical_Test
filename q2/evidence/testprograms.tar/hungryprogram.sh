#! /bin/bash

stress --vm 1 --vm-bytes 800M
