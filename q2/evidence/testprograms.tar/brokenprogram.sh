
while true
do
echo “Uh oh! Something went wrong.” >> /dev/kmsg
logger instaclustr “Uh oh! Something else went wrong.”
sleep 30
done
